package com.Excel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcelReadAndStoreFileApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcelReadAndStoreFileApplication.class, args);
	}

}
