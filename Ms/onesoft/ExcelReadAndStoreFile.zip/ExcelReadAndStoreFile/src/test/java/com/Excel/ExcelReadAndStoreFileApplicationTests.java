package com.Excel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExcelReadAndStoreFileApplicationTests {

	@Test
	void contextLoads() {
	}

}
