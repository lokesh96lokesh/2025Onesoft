package com.Gst;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GstApplication {

	public static void main(String[] args) {
		SpringApplication.run(GstApplication.class, args);
	}

}
