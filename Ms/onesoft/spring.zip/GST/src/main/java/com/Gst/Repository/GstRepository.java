package com.Gst.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Gst.Entity.GstEntity;

public interface GstRepository extends JpaRepository<GstEntity, Integer>{

}
