package com.example.Electronics.Exception;

public class StrorageCapacityException extends Exception {
	public StrorageCapacityException(String msg){
		super(msg);
	}
}
