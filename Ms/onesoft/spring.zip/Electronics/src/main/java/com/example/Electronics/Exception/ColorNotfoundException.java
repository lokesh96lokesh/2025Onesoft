package com.example.Electronics.Exception;

public class ColorNotfoundException extends Exception{
	public ColorNotfoundException(String msg){
		super(msg);
	}
}
