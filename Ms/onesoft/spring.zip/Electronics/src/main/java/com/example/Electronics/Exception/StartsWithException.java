package com.example.Electronics.Exception;

public class StartsWithException extends Exception{
	public StartsWithException(String msg){
		super(msg);
	}
}
