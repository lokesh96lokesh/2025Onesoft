package com.example.Electronics.Exception;

public class YearNotFoundException extends Exception{
	public YearNotFoundException(String msg) {
		super(msg);
	}
}
