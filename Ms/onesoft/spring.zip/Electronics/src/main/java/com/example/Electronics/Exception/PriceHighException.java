package com.example.Electronics.Exception;

public class PriceHighException extends Exception{
	public PriceHighException(String msg) {
		super(msg);
	}
}
