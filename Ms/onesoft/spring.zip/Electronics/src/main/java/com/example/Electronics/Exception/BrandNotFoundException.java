package com.example.Electronics.Exception;

public class BrandNotFoundException extends Exception{
	public BrandNotFoundException(String msg) {
		super(msg);
	}
}

