package com.example.Electronics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectronicsApplicationTests {

	@Test
	void contextLoads() {
	}

}
